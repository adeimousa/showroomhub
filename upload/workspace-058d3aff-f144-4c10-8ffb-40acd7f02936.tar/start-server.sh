#!/bin/bash
cd /home/z/my-project
node .next/standalone/server.js &
SERVER_PID=$!
echo "Server PID: $SERVER_PID"
# Keep the script running
wait $SERVER_PID
