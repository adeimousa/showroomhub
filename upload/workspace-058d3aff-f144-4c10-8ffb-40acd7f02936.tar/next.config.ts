import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
  },
  allowedDevOrigins: [
    'preview-chat-058d3aff-f144-4c10-8ffb-40acd7f02936.space-z.ai',
    '.space-z.ai',
  ],
};

export default nextConfig;
