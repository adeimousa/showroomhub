import { db } from '@/lib/db';
import bcrypt from 'bcryptjs';
import { UserRole, PaymentStatus, PaymentType } from '@prisma/client';

async function main() {
  console.log('🌱 Starting seed...');

  // Create super admin user
  const superAdminPassword = await bcrypt.hash('admin123', 10);
  const superAdmin = await db.user.upsert({
    where: { email: 'admin@platform.com' },
    update: {},
    create: {
      email: 'admin@platform.com',
      password: superAdminPassword,
      name: 'Platform Admin',
      role: UserRole.SUPER_ADMIN,
      isActive: true,
    },
  });
  console.log('✅ Created super admin:', superAdmin.email);

  // Create demo tenant
  const demoTenant = await db.tenant.upsert({
    where: { slug: 'demo-furniture' },
    update: {},
    create: {
      companyName: 'Demo Furniture Store',
      slug: 'demo-furniture',
      email: 'contact@demofurniture.com',
      phone: '+970-599-123456',
      address: 'Ramallah, Palestine',
      isActive: true,
      isPaused: false,
      defaultLanguage: 'en',
      enabledLanguages: JSON.stringify(['en', 'ar', 'he']),
      themeConfig: JSON.stringify({
        colors: {
          primary: '#2563eb',
          secondary: '#1e40af',
          accent: '#10b981',
          background: '#ffffff',
          text: '#1f2937',
        },
        typography: {
          headingFont: 'Inter',
          bodyFont: 'Inter',
        },
        layout: {
          headerStyle: 'centered',
          productGrid: 3,
          heroStyle: 'slider',
        },
        branding: {
          companyName: 'Demo Furniture Store',
          tagline: 'Quality Furniture for Your Home',
        },
      }),
      socialLinks: JSON.stringify({
        facebook: 'https://facebook.com/demofurniture',
        instagram: 'https://instagram.com/demofurniture',
        whatsapp: '+970599123456',
      }),
      expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year from now
    },
  });
  console.log('✅ Created demo tenant:', demoTenant.companyName);

  // Create tenant settings
  await db.tenantSettings.upsert({
    where: { tenantId: demoTenant.id },
    update: {},
    create: {
      tenantId: demoTenant.id,
      contactInfo: JSON.stringify({
        en: { address: 'Ramallah, Palestine', phone: '+970-599-123456' },
        ar: { address: 'رام الله، فلسطين', phone: '+970-599-123456' },
        he: { address: 'רמאללה, פלסטין', phone: '+970-599-123456' },
      }),
      features: JSON.stringify({
        showPrices: true,
        allowContactForm: true,
        showWhatsApp: true,
      }),
    },
  });

  // Create site config
  await db.siteConfig.upsert({
    where: { tenantId: demoTenant.id },
    update: {},
    create: {
      tenantId: demoTenant.id,
      headerStyle: 'centered',
      heroStyle: 'slider',
      productsPerPage: 12,
      productGridSize: 3,
      showPrices: true,
    },
  });

  // Create client admin for demo tenant
  const clientAdminPassword = await bcrypt.hash('demo123', 10);
  const clientAdmin = await db.user.upsert({
    where: { email: 'admin@demofurniture.com' },
    update: {},
    create: {
      email: 'admin@demofurniture.com',
      password: clientAdminPassword,
      name: 'Demo Store Admin',
      role: UserRole.CLIENT_ADMIN,
      tenantId: demoTenant.id,
      isActive: true,
    },
  });
  console.log('✅ Created client admin:', clientAdmin.email);

  // Create categories
  const categories = await Promise.all([
    db.category.upsert({
      where: { tenantId_slug: { tenantId: demoTenant.id, slug: 'living-room' } },
      update: {},
      create: {
        tenantId: demoTenant.id,
        name: JSON.stringify({ en: 'Living Room', ar: 'غرفة المعيشة', he: 'סלון' }),
        slug: 'living-room',
        description: JSON.stringify({
          en: 'Comfortable and stylish living room furniture',
          ar: 'أثاث غرفة معيشة مريح وأنيق',
          he: 'ריהוט סלון נוח וסטיילישי',
        }),
        order: 1,
        isActive: true,
      },
    }),
    db.category.upsert({
      where: { tenantId_slug: { tenantId: demoTenant.id, slug: 'bedroom' } },
      update: {},
      create: {
        tenantId: demoTenant.id,
        name: JSON.stringify({ en: 'Bedroom', ar: 'غرفة النوم', he: 'חדר שינה' }),
        slug: 'bedroom',
        description: JSON.stringify({
          en: 'Beautiful bedroom furniture for restful sleep',
          ar: 'أثاث غرفة نوم جميل لنوم مريح',
          he: 'ריהוט חדר שינה יפה לשינה מפנקת',
        }),
        order: 2,
        isActive: true,
      },
    }),
    db.category.upsert({
      where: { tenantId_slug: { tenantId: demoTenant.id, slug: 'dining-room' } },
      update: {},
      create: {
        tenantId: demoTenant.id,
        name: JSON.stringify({ en: 'Dining Room', ar: 'غرفة الطعام', he: 'חדר אוכל' }),
        slug: 'dining-room',
        description: JSON.stringify({
          en: 'Elegant dining room sets and furniture',
          ar: 'طقم غرفة طعام وأثاث أنيق',
          he: 'סטיים וריהוט לחדר אוכל אלגנטי',
        }),
        order: 3,
        isActive: true,
      },
    }),
  ]);
  console.log('✅ Created', categories.length, 'categories');

  // Create sample products
  const products = await Promise.all([
    db.product.upsert({
      where: { tenantId_slug: { tenantId: demoTenant.id, slug: 'modern-sofa' } },
      update: {},
      create: {
        tenantId: demoTenant.id,
        categoryId: categories[0].id,
        name: JSON.stringify({ en: 'Modern Sofa', ar: 'أريكة عصرية', he: 'ספה מודרנית' }),
        description: JSON.stringify({
          en: 'A comfortable 3-seater modern sofa with premium fabric',
          ar: 'أريكة عصرية مريحة لثلاثة أشخاص بقماش فاخر',
          he: 'ספה מודרנית נוחה ל-3 מושבים עם בד פרימיום',
        }),
        slug: 'modern-sofa',
        price: 1299.99,
        comparePrice: 1499.99,
        currency: 'USD',
        showPrice: true,
        inStock: true,
        stockQuantity: 10,
        isFeatured: true,
        isNew: true,
        isActive: true,
        features: JSON.stringify([
          { en: 'Premium fabric', ar: 'قماش فاخر', he: 'בד פרימיום' },
          { en: '3-seater', ar: 'ثلاثة مقاعد', he: '3 מושבים' },
          { en: 'Easy to clean', ar: 'سهل التنظيف', he: 'קל לניקוי' },
        ]),
      },
    }),
    db.product.upsert({
      where: { tenantId_slug: { tenantId: demoTenant.id, slug: 'king-bed-frame' } },
      update: {},
      create: {
        tenantId: demoTenant.id,
        categoryId: categories[1].id,
        name: JSON.stringify({ en: 'King Bed Frame', ar: 'إطار سرير كينج', he: 'מסגרת מיטת קינג' }),
        description: JSON.stringify({
          en: 'Luxurious king-size bed frame with upholstered headboard',
          ar: 'إطار سرير كينج فاخر مع مسند رأس مبطن',
          he: 'מסגרת מיטת קינג מפוארת עם משענת ראש מרופדת',
        }),
        slug: 'king-bed-frame',
        price: 899.99,
        comparePrice: 1099.99,
        currency: 'USD',
        showPrice: true,
        inStock: true,
        stockQuantity: 5,
        isFeatured: true,
        isActive: true,
        features: JSON.stringify([
          { en: 'King size', ar: 'حجم كينج', he: 'גודל קינג' },
          { en: 'Upholstered headboard', ar: 'مسند رأس مبطن', he: 'משענת ראש מרופדת' },
          { en: 'Solid wood frame', ar: 'إطار خشب صلب', he: 'מסגרת עץ מלא' },
        ]),
      },
    }),
    db.product.upsert({
      where: { tenantId_slug: { tenantId: demoTenant.id, slug: 'dining-table-set' } },
      update: {},
      create: {
        tenantId: demoTenant.id,
        categoryId: categories[2].id,
        name: JSON.stringify({ en: 'Dining Table Set', ar: 'طقم طاولة طعام', he: 'סט שולחן אוכל' }),
        description: JSON.stringify({
          en: 'Elegant 6-piece dining table set with comfortable chairs',
          ar: 'طقم طاولة طعام أنيق من 6 قطع مع كراسي مريحة',
          he: 'סט שולחן אוכל אלגנטי של 6 פריטים עם כיסאות נוחים',
        }),
        slug: 'dining-table-set',
        price: 1599.99,
        comparePrice: 1899.99,
        currency: 'USD',
        showPrice: true,
        inStock: true,
        stockQuantity: 3,
        isFeatured: true,
        isNew: true,
        isActive: true,
        features: JSON.stringify([
          { en: '6-piece set', ar: 'طقم 6 قطع', he: 'סט של 6 פריטים' },
          { en: 'Solid wood', ar: 'خشب صلب', he: 'עץ מלא' },
          { en: 'Comfortable chairs', ar: 'كراسي مريحة', he: 'כיסאות נוחים' },
        ]),
      },
    }),
  ]);
  console.log('✅ Created', products.length, 'products');

  // Create hero slides
  await Promise.all([
    db.heroSlide.upsert({
      where: { id: 'slide-1' },
      update: {},
      create: {
        id: 'slide-1',
        tenantId: demoTenant.id,
        title: JSON.stringify({
          en: 'Welcome to Demo Furniture',
          ar: 'مرحباً بكم في ديمو للأثاث',
          he: 'ברוכים הבאים לדמו ריהוט',
        }),
        subtitle: JSON.stringify({
          en: 'Quality furniture for your dream home',
          ar: 'أثاث عالي الجودة لمنزل أحلامك',
          he: 'ריהוט איכותי לבית החלומות שלך',
        }),
        buttonText: JSON.stringify({ en: 'Shop Now', ar: 'تسوق الآن', he: 'קנה עכשיו' }),
        buttonLink: '/products',
        image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=1920&q=80',
        order: 1,
        isActive: true,
      },
    }),
    db.heroSlide.upsert({
      where: { id: 'slide-2' },
      update: {},
      create: {
        id: 'slide-2',
        tenantId: demoTenant.id,
        title: JSON.stringify({
          en: 'Modern Living Room Collections',
          ar: 'مجموعات غرف معيشة عصرية',
          he: 'קולקציות סלון מודרניות',
        }),
        subtitle: JSON.stringify({
          en: 'Discover our latest arrivals',
          ar: 'اكتشف أحدث وصولنا',
          he: 'גלה את החדשים שלנו',
        }),
        buttonText: JSON.stringify({ en: 'Explore', ar: 'استكشف', he: 'חקור' }),
        buttonLink: '/categories/living-room',
        image: 'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?w=1920&q=80',
        order: 2,
        isActive: true,
      },
    }),
  ]);
  console.log('✅ Created hero slides');

  // Create sample payment
  await db.payment.upsert({
    where: { id: 'payment-1' },
    update: {},
    create: {
      id: 'payment-1',
      tenantId: demoTenant.id,
      type: PaymentType.SUBSCRIPTION,
      amount: 299.99,
      currency: 'USD',
      status: PaymentStatus.PAID,
      dueDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
      paidAt: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000),
      periodStart: new Date(Date.now() - 365 * 24 * 60 * 60 * 1000),
      periodEnd: new Date(Date.now()),
      paymentMethod: 'bank_transfer',
      referenceNumber: 'INV-2024-001',
      invoiceNumber: 'INV-2024-001',
    },
  });
  console.log('✅ Created sample payment');

  console.log('🎉 Seed completed successfully!');
  console.log('');
  console.log('📝 Login credentials:');
  console.log('   Super Admin: admin@platform.com / admin123');
  console.log('   Client Admin: admin@demofurniture.com / demo123');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
