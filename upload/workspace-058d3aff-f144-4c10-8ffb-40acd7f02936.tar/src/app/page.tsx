'use client';

import { useEffect, useState, useMemo } from 'react';
import { useSession, signOut } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { Label } from '@/components/ui/label';
import { 
  Users, 
  Building2, 
  DollarSign, 
  Package, 
  Settings, 
  LogOut, 
  LayoutDashboard,
  ShoppingBag,
  Image,
  CreditCard,
  BarChart3,
  ChevronDown,
  Play,
  Pause,
  ExternalLink,
  Plus,
  Edit,
  Trash2,
  Eye,
  Loader2,
  LayoutGrid
} from 'lucide-react';
import { LoginForm } from '@/components/auth/login-form';
import { LayoutGallery } from '@/components/super-admin/layout-gallery';

// Super Admin Dashboard Component
function SuperAdminDashboard() {
  const [tenants, setTenants] = useState<any[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [tenantsRes, paymentsRes] = await Promise.all([
        fetch('/api/admin/tenants'),
        fetch('/api/admin/payments')
      ]);
      
      if (tenantsRes.ok) {
        const data = await tenantsRes.json();
        setTenants(data.tenants || []);
      }
      
      if (paymentsRes.ok) {
        const data = await paymentsRes.json();
        setPayments(data.payments || []);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleTenantStatus = async (tenantId: string, action: 'pause' | 'resume') => {
    try {
      const res = await fetch(`/api/admin/tenants/${tenantId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action })
      });
      
      if (res.ok) {
        fetchData();
      }
    } catch (error) {
      console.error('Error updating tenant:', error);
    }
  };

  const activeTenants = tenants.filter(t => t.isActive && !t.isPaused).length;
  const pausedTenants = tenants.filter(t => t.isPaused).length;
  const totalRevenue = payments
    .filter(p => p.status === 'PAID')
    .reduce((sum, p) => sum + (p.amount || 0), 0);
  const pendingPayments = payments.filter(p => p.status === 'PENDING').length;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <Building2 className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-xl font-bold">Furniture Platform</h1>
                <p className="text-xs text-muted-foreground">Super Admin Panel</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Button variant="outline" size="sm" asChild>
                <a href="/?view=site" target="_blank">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View Demo Site
                </a>
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback>SA</AvatarFallback>
                    </Avatar>
                    <span className="hidden sm:inline">Admin</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => signOut({ callbackUrl: '/' })}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Tenants</CardTitle>
              <Users className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{tenants.length}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {activeTenants} active, {pausedTenants} paused
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Revenue</CardTitle>
              <DollarSign className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">${totalRevenue.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground mt-1">From paid invoices</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Pending Payments</CardTitle>
              <CreditCard className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{pendingPayments}</div>
              <p className="text-xs text-muted-foreground mt-1">Awaiting payment</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Sites</CardTitle>
              <BarChart3 className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{activeTenants}</div>
              <Progress value={(activeTenants / tenants.length) * 100 || 0} className="mt-2 h-2" />
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="tenants" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 max-w-lg">
            <TabsTrigger value="tenants" className="gap-2">
              <Users className="h-4 w-4" />
              Tenants
            </TabsTrigger>
            <TabsTrigger value="layouts" className="gap-2">
              <LayoutGrid className="h-4 w-4" />
              Layouts
            </TabsTrigger>
            <TabsTrigger value="payments" className="gap-2">
              <CreditCard className="h-4 w-4" />
              Payments
            </TabsTrigger>
          </TabsList>

          <TabsContent value="tenants">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <CardTitle>Tenant Management</CardTitle>
                    <CardDescription>Manage all client websites and subscriptions</CardDescription>
                  </div>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Tenant
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="text-center py-8 text-muted-foreground">Loading...</div>
                ) : tenants.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">No tenants found</div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Company</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Layout</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Expires</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {tenants.map((tenant) => (
                          <TableRow key={tenant.id}>
                            <TableCell>
                              <div>
                                <p className="font-medium">{tenant.companyName}</p>
                                <p className="text-xs text-muted-foreground">{tenant.slug}</p>
                              </div>
                            </TableCell>
                            <TableCell>{tenant.email}</TableCell>
                            <TableCell>
                              {tenant.layout ? (
                                <Badge variant="outline" className="capitalize">
                                  {tenant.layout.name}
                                </Badge>
                              ) : (
                                <span className="text-xs text-muted-foreground">No layout</span>
                              )}
                            </TableCell>
                            <TableCell>
                              {tenant.isPaused ? (
                                <Badge variant="destructive">Paused</Badge>
                              ) : tenant.isActive ? (
                                <Badge variant="default" className="bg-green-500">Active</Badge>
                              ) : (
                                <Badge variant="secondary">Inactive</Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              {tenant.expiresAt 
                                ? new Date(tenant.expiresAt).toLocaleDateString()
                                : 'N/A'}
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-2">
                                <Button variant="ghost" size="icon" title="View">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" title="Edit">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                {tenant.isPaused ? (
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    title="Resume"
                                    onClick={() => toggleTenantStatus(tenant.id, 'resume')}
                                    className="text-green-500 hover:text-green-600"
                                  >
                                    <Play className="h-4 w-4" />
                                  </Button>
                                ) : (
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    title="Pause"
                                    onClick={() => toggleTenantStatus(tenant.id, 'pause')}
                                    className="text-orange-500 hover:text-orange-600"
                                  >
                                    <Pause className="h-4 w-4" />
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="layouts">
            <LayoutGallery 
              tenants={tenants} 
              onAssignLayout={() => fetchData()}
            />
          </TabsContent>

          <TabsContent value="payments">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <CardTitle>Payment Management</CardTitle>
                    <CardDescription>Track and manage subscription payments</CardDescription>
                  </div>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Payment
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="text-center py-8 text-muted-foreground">Loading...</div>
                ) : payments.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">No payments found</div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Tenant</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Due Date</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {payments.map((payment) => (
                          <TableRow key={payment.id}>
                            <TableCell className="font-medium">
                              {payment.tenant?.companyName || 'N/A'}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{payment.type}</Badge>
                            </TableCell>
                            <TableCell>${payment.amount?.toLocaleString()}</TableCell>
                            <TableCell>
                              {new Date(payment.dueDate).toLocaleDateString()}
                            </TableCell>
                            <TableCell>
                              <Badge 
                                variant={
                                  payment.status === 'PAID' ? 'default' :
                                  payment.status === 'PENDING' ? 'secondary' :
                                  payment.status === 'OVERDUE' ? 'destructive' : 'outline'
                                }
                                className={payment.status === 'PAID' ? 'bg-green-500' : ''}
                              >
                                {payment.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-2">
                                <Button variant="ghost" size="icon" title="Edit">
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

// Client Admin Dashboard Component
function ClientAdminDashboard() {
  const { data: session } = useSession();
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [tenant, setTenant] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (session?.user?.tenantId) {
      fetchData();
    }
  }, [session]);

  const fetchData = async () => {
    try {
      const [productsRes, categoriesRes] = await Promise.all([
        fetch('/api/client/products'),
        fetch('/api/client/categories')
      ]);
      
      if (productsRes.ok) {
        const data = await productsRes.json();
        setProducts(data.products || []);
      }
      
      if (categoriesRes.ok) {
        const data = await categoriesRes.json();
        setCategories(data.categories || []);
      }
      
      // Fetch tenant info
      if (session?.user?.tenantId) {
        const tenantRes = await fetch('/api/client/tenant');
        if (tenantRes.ok) {
          const data = await tenantRes.json();
          setTenant(data.tenant);
        }
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const themeConfig = tenant?.themeConfig ? JSON.parse(tenant.themeConfig) : {};
  const colors = themeConfig?.colors || {};

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div 
                className="h-10 w-10 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: colors.primary || '#2563eb' }}
              >
                <ShoppingBag className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold">{tenant?.companyName || 'My Store'}</h1>
                <p className="text-xs text-muted-foreground">Client Admin Panel</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Button variant="outline" size="sm" asChild>
                <a href="/?view=site" target="_blank">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View Site
                </a>
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback>{session?.user?.name?.charAt(0) || 'U'}</AvatarFallback>
                    </Avatar>
                    <span className="hidden sm:inline">{session?.user?.name}</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Settings className="h-4 w-4 mr-2" />
                    Settings
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => signOut({ callbackUrl: '/' })}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Products</CardTitle>
              <Package className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{products.length}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {products.filter(p => p.isActive).length} active
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Categories</CardTitle>
              <LayoutDashboard className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{categories.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Featured</CardTitle>
              <Eye className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {products.filter(p => p.isFeatured).length}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Site Status</CardTitle>
              <BarChart3 className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <Badge variant={tenant?.isPaused ? "destructive" : "default"} className={tenant?.isPaused ? "" : "bg-green-500"}>
                {tenant?.isPaused ? 'Paused' : 'Live'}
              </Badge>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="products" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 max-w-md">
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="categories">Categories</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="products">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <CardTitle>Product Management</CardTitle>
                    <CardDescription>Manage your product catalog</CardDescription>
                  </div>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Product
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="text-center py-8 text-muted-foreground">Loading...</div>
                ) : products.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">No products found</div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {products.map((product) => {
                      const name = JSON.parse(product.name || '{}');
                      const images = JSON.parse(product.images || '[]');
                      return (
                        <Card key={product.id} className="overflow-hidden">
                          <div className="aspect-video bg-muted relative">
                            {images[0] ? (
                              <img src={images[0]} alt={name.en} className="object-cover w-full h-full" />
                            ) : (
                              <div className="flex items-center justify-center h-full">
                                <Image className="h-12 w-12 text-muted-foreground/50" />
                              </div>
                            )}
                            {product.isFeatured && (
                              <Badge className="absolute top-2 right-2">Featured</Badge>
                            )}
                          </div>
                          <CardContent className="p-4">
                            <h3 className="font-semibold truncate">{name.en}</h3>
                            <div className="flex items-center justify-between mt-2">
                              <p className="text-lg font-bold">
                                ${product.price?.toLocaleString()}
                              </p>
                              <Badge variant={product.inStock ? "default" : "secondary"} className={product.inStock ? "bg-green-500" : ""}>
                                {product.inStock ? 'In Stock' : 'Out of Stock'}
                              </Badge>
                            </div>
                            <div className="flex gap-2 mt-3">
                              <Button variant="outline" size="sm" className="flex-1">
                                <Edit className="h-4 w-4 mr-1" />
                                Edit
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="categories">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <CardTitle>Category Management</CardTitle>
                    <CardDescription>Organize your products into categories</CardDescription>
                  </div>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Category
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="text-center py-8 text-muted-foreground">Loading...</div>
                ) : categories.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">No categories found</div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {categories.map((category) => {
                      const name = JSON.parse(category.name || '{}');
                      const productCount = products.filter(p => p.categoryId === category.id).length;
                      return (
                        <Card key={category.id}>
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              <h3 className="font-semibold">{name.en}</h3>
                              <Badge variant="outline">{productCount} products</Badge>
                            </div>
                            <div className="flex gap-2 mt-3">
                              <Button variant="outline" size="sm" className="flex-1">
                                <Edit className="h-4 w-4 mr-1" />
                                Edit
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Site Settings</CardTitle>
                <CardDescription>Customize your website appearance and settings</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h4 className="font-medium mb-3">Theme Colors</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <Label className="text-sm text-muted-foreground">Primary</Label>
                        <div 
                          className="h-12 rounded-lg mt-1 border"
                          style={{ backgroundColor: colors.primary || '#2563eb' }}
                        />
                      </div>
                      <div>
                        <Label className="text-sm text-muted-foreground">Secondary</Label>
                        <div 
                          className="h-12 rounded-lg mt-1 border"
                          style={{ backgroundColor: colors.secondary || '#1e40af' }}
                        />
                      </div>
                      <div>
                        <Label className="text-sm text-muted-foreground">Accent</Label>
                        <div 
                          className="h-12 rounded-lg mt-1 border"
                          style={{ backgroundColor: colors.accent || '#10b981' }}
                        />
                      </div>
                      <div>
                        <Label className="text-sm text-muted-foreground">Background</Label>
                        <div 
                          className="h-12 rounded-lg mt-1 border"
                          style={{ backgroundColor: colors.background || '#ffffff' }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <Button>Edit Theme</Button>
                    <Button variant="outline">Manage Languages</Button>
                    <Button variant="outline">Upload Logo</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

// Public Tenant Site Preview
function PublicSitePreview() {
  const [tenant, setTenant] = useState<any>(null);
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [heroSlides, setHeroSlides] = useState<any[]>([]);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [language, setLanguage] = useState<'en' | 'ar' | 'he'>('en');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchSiteData();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % heroSlides.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [heroSlides.length]);

  const fetchSiteData = async () => {
    try {
      const [tenantRes, productsRes, categoriesRes, slidesRes] = await Promise.all([
        fetch('/api/public/tenant'),
        fetch('/api/public/products'),
        fetch('/api/public/categories'),
        fetch('/api/public/slides')
      ]);
      
      if (tenantRes.ok) {
        const data = await tenantRes.json();
        setTenant(data.tenant);
      }
      if (productsRes.ok) {
        const data = await productsRes.json();
        setProducts(data.products || []);
      }
      if (categoriesRes.ok) {
        const data = await categoriesRes.json();
        setCategories(data.categories || []);
      }
      if (slidesRes.ok) {
        const data = await slidesRes.json();
        setHeroSlides(data.slides || []);
      }
    } catch (error) {
      console.error('Error fetching site data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const themeConfig = tenant?.themeConfig ? JSON.parse(tenant.themeConfig) : {};
  const colors = themeConfig?.colors || {};
  const branding = themeConfig?.branding || {};

  const getLocalizedText = (jsonStr: string | null) => {
    if (!jsonStr) return '';
    try {
      const parsed = JSON.parse(jsonStr);
      return parsed[language] || parsed['en'] || '';
    } catch {
      return jsonStr;
    }
  };

  const isRTL = language === 'ar' || language === 'he';

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen"
      style={{ 
        backgroundColor: colors.background || '#ffffff',
        color: colors.text || '#1f2937',
        direction: isRTL ? 'rtl' : 'ltr'
      }}
    >
      {/* Header */}
      <header 
        className="sticky top-0 z-50 shadow-sm"
        style={{ backgroundColor: colors.primary || '#2563eb' }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <ShoppingBag className="h-8 w-8 text-white" />
              <div>
                <h1 className="text-xl font-bold text-white">
                  {branding.companyName || tenant?.companyName || 'Furniture Store'}
                </h1>
              </div>
            </div>
            
            <nav className="hidden md:flex items-center gap-6">
              {categories.slice(0, 4).map((cat) => {
                const name = JSON.parse(cat.name || '{}');
                return (
                  <a 
                    key={cat.id} 
                    href="#" 
                    className="text-white/90 hover:text-white transition-colors"
                  >
                    {name[language] || name['en']}
                  </a>
                );
              })}
            </nav>

            <div className="flex items-center gap-2">
              <select 
                value={language}
                onChange={(e) => setLanguage(e.target.value as any)}
                className="bg-white/20 text-white border-white/30 rounded px-2 py-1 text-sm"
              >
                <option value="en">English</option>
                <option value="ar">العربية</option>
                <option value="he">עברית</option>
              </select>
              <Button 
                variant="outline" 
                size="sm"
                className="bg-white/20 border-white/30 text-white hover:bg-white/30"
                onClick={() => window.location.href = '/'}
              >
                Admin
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Slider */}
      {heroSlides.length > 0 && (
        <section className="relative h-[60vh] overflow-hidden">
          {heroSlides.map((slide, index) => (
            <div
              key={slide.id}
              className={`absolute inset-0 transition-opacity duration-500 ${
                index === currentSlide ? 'opacity-100' : 'opacity-0'
              }`}
            >
              <img
                src={slide.image}
                alt={getLocalizedText(slide.title)}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/40" />
              <div className="absolute inset-0 flex items-center justify-center text-center text-white p-8">
                <div>
                  <h2 className="text-4xl md:text-6xl font-bold mb-4">
                    {getLocalizedText(slide.title)}
                  </h2>
                  <p className="text-xl md:text-2xl mb-6 opacity-90">
                    {getLocalizedText(slide.subtitle)}
                  </p>
                  {slide.buttonLink && (
                    <Button 
                      size="lg"
                      style={{ backgroundColor: colors.accent || '#10b981' }}
                    >
                      {getLocalizedText(slide.buttonText)}
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
          
          {/* Slide indicators */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
            {heroSlides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentSlide ? 'bg-white' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        </section>
      )}

      {/* Categories */}
      <section className="py-12 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-center mb-8">
            {language === 'ar' ? 'تصفح حسب الفئة' : language === 'he' ? 'עיון לפי קטגוריה' : 'Browse by Category'}
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {categories.map((cat) => {
              const name = JSON.parse(cat.name || '{}');
              const description = cat.description ? JSON.parse(cat.description) : {};
              return (
                <Card key={cat.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-4">
                    <h3 className="font-semibold">{name[language] || name['en']}</h3>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                      {description[language] || description['en']}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-center mb-8">
            {language === 'ar' ? 'منتجات مميزة' : language === 'he' ? 'מוצרים מומלצים' : 'Featured Products'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.filter(p => p.isFeatured).map((product) => {
              const name = JSON.parse(product.name || '{}');
              const images = JSON.parse(product.images || '[]');
              return (
                <Card key={product.id} className="overflow-hidden group hover:shadow-lg transition-all">
                  <div className="aspect-video bg-muted relative overflow-hidden">
                    {images[0] ? (
                      <img 
                        src={images[0]} 
                        alt={name[language] || name['en']} 
                        className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full bg-muted">
                        <Image className="h-12 w-12 text-muted-foreground/50" />
                      </div>
                    )}
                    {product.isNew && (
                      <Badge className="absolute top-2 left-2" style={{ backgroundColor: colors.accent }}>
                        {language === 'ar' ? 'جديد' : language === 'he' ? 'חדש' : 'New'}
                      </Badge>
                    )}
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-lg">{name[language] || name['en']}</h3>
                    <div className="flex items-center justify-between mt-2">
                      <div>
                        {product.showPrice && (
                          <p className="text-lg font-bold" style={{ color: colors.primary }}>
                            ${product.price?.toLocaleString()}
                          </p>
                        )}
                      </div>
                      <Badge variant={product.inStock ? "default" : "secondary"} className={product.inStock ? "bg-green-500" : ""}>
                        {product.inStock 
                          ? (language === 'ar' ? 'متوفر' : language === 'he' ? 'במלאי' : 'In Stock')
                          : (language === 'ar' ? 'غير متوفر' : language === 'he' ? 'אזל' : 'Out of Stock')
                        }
                      </Badge>
                    </div>
                    <Button 
                      className="w-full mt-3"
                      style={{ backgroundColor: colors.primary }}
                    >
                      {language === 'ar' ? 'عرض التفاصيل' : language === 'he' ? 'צפה בפרטים' : 'View Details'}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer 
        className="py-8 text-white"
        style={{ backgroundColor: colors.primary || '#2563eb' }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-lg font-semibold mb-2">
            {branding.companyName || tenant?.companyName}
          </p>
          {branding.tagline && (
            <p className="text-white/80 mb-4">{branding.tagline}</p>
          )}
          <p className="text-sm text-white/60">
            {language === 'ar' ? 'جميع الحقوق محفوظة' : language === 'he' ? 'כל הזכויות שמורות' : 'All Rights Reserved'} 
            {' '}© {new Date().getFullYear()}
          </p>
        </div>
      </footer>
    </div>
  );
}

// Main Page Component
export default function HomePage() {
  const { data: session, status } = useSession();
  
  // Check URL params for view mode using useMemo to avoid setState in effect
  const initialView = useMemo(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('view') === 'site') {
        return 'site' as const;
      }
    }
    return 'dashboard' as const;
  }, []);

  const [view, setView] = useState<'dashboard' | 'site'>(initialView);

  // Loading state
  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  // Not authenticated - show login
  if (status === 'unauthenticated') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-4">
        <LoginForm />
      </div>
    );
  }

  // View public site
  if (view === 'site') {
    return <PublicSitePreview />;
  }

  // Authenticated - show appropriate dashboard
  if (session?.user?.role === 'SUPER_ADMIN') {
    return <SuperAdminDashboard />;
  }

  return <ClientAdminDashboard />;
}
