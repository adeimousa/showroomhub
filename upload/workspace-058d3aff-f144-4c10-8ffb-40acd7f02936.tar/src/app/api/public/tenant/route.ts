import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get tenant info for public site (demo tenant)
export async function GET() {
  try {
    const tenant = await db.tenant.findFirst({
      where: { isActive: true, isPaused: false },
      include: {
        settings: true,
        siteConfig: true,
        layout: true
      }
    });

    return NextResponse.json({ tenant });
  } catch (error) {
    console.error('Error fetching tenant:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
