import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List products for public tenant site (demo tenant)
export async function GET() {
  try {
    // For demo, get the first active tenant
    const tenant = await db.tenant.findFirst({
      where: { isActive: true, isPaused: false }
    });

    if (!tenant) {
      return NextResponse.json({ products: [] });
    }

    const products = await db.product.findMany({
      where: { 
        tenantId: tenant.id,
        isActive: true 
      },
      orderBy: { order: 'asc' },
      include: {
        category: {
          select: { id: true, name: true, slug: true }
        }
      }
    });

    return NextResponse.json({ products });
  } catch (error) {
    console.error('Error fetching products:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
