import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - List hero slides for public tenant site (demo tenant)
export async function GET() {
  try {
    const tenant = await db.tenant.findFirst({
      where: { isActive: true, isPaused: false }
    });

    if (!tenant) {
      return NextResponse.json({ slides: [] });
    }

    const slides = await db.heroSlide.findMany({
      where: { 
        tenantId: tenant.id,
        isActive: true 
      },
      orderBy: { order: 'asc' }
    });

    return NextResponse.json({ slides });
  } catch (error) {
    console.error('Error fetching slides:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
