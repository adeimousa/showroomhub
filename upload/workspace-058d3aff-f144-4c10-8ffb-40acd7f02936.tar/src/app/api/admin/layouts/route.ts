import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { layouts } from '@/lib/layouts-data';

// GET - List all layouts
export async function GET() {
  try {
    const allLayouts = await db.layout.findMany({
      orderBy: [
        { category: 'asc' },
        { order: 'asc' }
      ],
      include: {
        _count: {
          select: { tenants: true }
        }
      }
    });

    // If no layouts exist, seed them
    if (allLayouts.length === 0) {
      for (const layout of layouts) {
        await db.layout.create({
          data: {
            name: layout.name,
            slug: layout.slug,
            description: layout.description,
            category: layout.category,
            isPremium: layout.isPremium,
            order: layout.order,
            config: layout.config,
            isActive: true
          }
        });
      }
      
      const seededLayouts = await db.layout.findMany({
        orderBy: [
          { category: 'asc' },
          { order: 'asc' }
        ],
        include: {
          _count: {
            select: { tenants: true }
          }
        }
      });
      
      return NextResponse.json({ layouts: seededLayouts });
    }

    return NextResponse.json({ layouts: allLayouts });
  } catch (error) {
    console.error('Error fetching layouts:', error);
    return NextResponse.json(
      { error: 'Failed to fetch layouts' },
      { status: 500 }
    );
  }
}

// POST - Create new layout (Super Admin only)
export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    
    const layout = await db.layout.create({
      data: {
        name: data.name,
        slug: data.slug || data.name.toLowerCase().replace(/\s+/g, '-'),
        description: data.description,
        category: data.category || 'modern',
        isPremium: data.isPremium || false,
        config: JSON.stringify(data.config || {}),
        isActive: data.isActive ?? true,
        thumbnailUrl: data.thumbnailUrl,
        previewUrl: data.previewUrl
      }
    });

    return NextResponse.json({ layout });
  } catch (error) {
    console.error('Error creating layout:', error);
    return NextResponse.json(
      { error: 'Failed to create layout' },
      { status: 500 }
    );
  }
}
