import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get single layout
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const layout = await db.layout.findUnique({
      where: { id },
      include: {
        tenants: {
          select: {
            id: true,
            companyName: true,
            slug: true
          }
        }
      }
    });

    if (!layout) {
      return NextResponse.json(
        { error: 'Layout not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({ layout });
  } catch (error) {
    console.error('Error fetching layout:', error);
    return NextResponse.json(
      { error: 'Failed to fetch layout' },
      { status: 500 }
    );
  }
}

// PATCH - Update layout
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const data = await request.json();
    
    const layout = await db.layout.update({
      where: { id },
      data: {
        name: data.name,
        slug: data.slug,
        description: data.description,
        category: data.category,
        isPremium: data.isPremium,
        config: data.config ? JSON.stringify(data.config) : undefined,
        isActive: data.isActive,
        thumbnailUrl: data.thumbnailUrl,
        previewUrl: data.previewUrl,
        order: data.order
      }
    });

    return NextResponse.json({ layout });
  } catch (error) {
    console.error('Error updating layout:', error);
    return NextResponse.json(
      { error: 'Failed to update layout' },
      { status: 500 }
    );
  }
}

// DELETE - Delete layout (only if not assigned to any tenant)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // Check if layout is assigned to any tenant
    const tenantsCount = await db.tenant.count({
      where: { layoutId: id }
    });

    if (tenantsCount > 0) {
      return NextResponse.json(
        { error: 'Cannot delete layout that is assigned to tenants' },
        { status: 400 }
      );
    }

    await db.layout.delete({
      where: { id }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting layout:', error);
    return NextResponse.json(
      { error: 'Failed to delete layout' },
      { status: 500 }
    );
  }
}
