import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { db } from '@/lib/db';
import { authOptions } from '@/lib/auth';

// GET - List all tenants
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const tenants = await db.tenant.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        layout: {
          select: {
            id: true,
            name: true,
            slug: true,
            category: true
          }
        },
        _count: {
          select: { products: true, users: true, payments: true }
        }
      }
    });

    return NextResponse.json({ tenants });
  } catch (error) {
    console.error('Error fetching tenants:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST - Create new tenant
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || session.user.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { companyName, slug, email, phone, address, customDomain, defaultLanguage, layoutId } = body;

    const tenant = await db.tenant.create({
      data: {
        companyName,
        slug,
        email,
        phone,
        address,
        customDomain,
        defaultLanguage: defaultLanguage || 'en',
        layoutId: layoutId || null,
        themeConfig: JSON.stringify({
          colors: { primary: '#2563eb', secondary: '#1e40af', accent: '#10b981' },
          typography: { headingFont: 'Inter', bodyFont: 'Inter' },
          layout: { headerStyle: 'centered', productGrid: 3 }
        })
      },
      include: {
        layout: true
      }
    });

    return NextResponse.json({ tenant });
  } catch (error) {
    console.error('Error creating tenant:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
