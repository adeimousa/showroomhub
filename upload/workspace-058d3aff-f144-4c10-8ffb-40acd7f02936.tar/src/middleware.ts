import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  
  // Skip middleware for API routes and static files
  if (
    pathname.startsWith('/api') ||
    pathname.startsWith('/_next') ||
    pathname.includes('.') ||
    pathname.startsWith('/uploads')
  ) {
    return NextResponse.next();
  }

  // For all routes, just continue
  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!api|_next|_vercel|uploads|.*\\..*).*)']
};
