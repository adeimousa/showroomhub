'use client';

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  LayoutGrid, 
  Crown, 
  Check, 
  Eye, 
  Users,
  Sparkles,
  Palette,
  Monitor,
  Layers,
  Wand2
} from 'lucide-react';

interface Layout {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  category: string;
  isPremium: boolean;
  isActive: boolean;
  config: string;
  thumbnailUrl: string | null;
  _count?: { tenants: number };
}

interface LayoutGalleryProps {
  onAssignLayout?: (layoutId: string, tenantId: string) => void;
  tenants?: any[];
}

const categoryColors: Record<string, string> = {
  modern: 'bg-blue-500',
  luxury: 'bg-amber-500',
  minimal: 'bg-gray-500',
  creative: 'bg-purple-500',
  classic: 'bg-emerald-500',
};

const categoryIcons: Record<string, any> = {
  modern: Monitor,
  luxury: Crown,
  minimal: Layers,
  creative: Sparkles,
  classic: Palette,
};

// Generate a gradient for layout preview based on category
const getLayoutGradient = (category: string, slug: string) => {
  const gradients: Record<string, string[]> = {
    modern: [
      'from-slate-100 to-slate-300',
      'from-blue-100 to-blue-300',
      'from-cyan-100 to-cyan-300',
      'from-indigo-100 to-indigo-300',
      'from-sky-100 to-sky-300',
      'from-violet-100 to-violet-300',
    ],
    luxury: [
      'from-amber-100 to-yellow-300',
      'from-stone-200 to-stone-400',
      'from-zinc-800 to-zinc-900',
      'from-neutral-100 to-neutral-300',
      'from-yellow-100 to-amber-400',
      'from-orange-100 to-orange-300',
    ],
    minimal: [
      'from-gray-50 to-gray-200',
      'from-slate-50 to-slate-200',
      'from-zinc-100 to-zinc-300',
      'from-stone-100 to-stone-200',
      'from-neutral-50 to-neutral-200',
      'from-white to-gray-100',
    ],
    creative: [
      'from-purple-200 to-pink-300',
      'from-fuchsia-200 to-purple-400',
      'from-rose-200 to-pink-400',
      'from-violet-300 to-purple-500',
      'from-pink-200 to-rose-400',
      'from-indigo-300 to-violet-500',
    ],
    classic: [
      'from-emerald-100 to-green-300',
      'from-teal-100 to-teal-300',
      'from-green-100 to-emerald-300',
      'from-lime-100 to-lime-300',
      'from-cyan-100 to-teal-300',
      'from-sky-100 to-cyan-300',
    ],
  };
  
  const categoryGradients = gradients[category] || gradients.modern;
  const index = slug.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) % categoryGradients.length;
  return categoryGradients[index];
};

export function LayoutGallery({ onAssignLayout, tenants = [] }: LayoutGalleryProps) {
  const [layouts, setLayouts] = useState<Layout[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedLayout, setSelectedLayout] = useState<Layout | null>(null);
  const [showAssignDialog, setShowAssignDialog] = useState(false);
  const [selectedTenantId, setSelectedTenantId] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchLayouts();
  }, []);

  const fetchLayouts = async () => {
    try {
      const res = await fetch('/api/admin/layouts');
      if (res.ok) {
        const data = await res.json();
        setLayouts(data.layouts || []);
      }
    } catch (error) {
      console.error('Error fetching layouts:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAssignLayout = async () => {
    if (!selectedLayout || !selectedTenantId) return;
    
    try {
      const res = await fetch(`/api/admin/tenants/${selectedTenantId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ layoutId: selectedLayout.id })
      });
      
      if (res.ok) {
        setShowAssignDialog(false);
        setSelectedLayout(null);
        setSelectedTenantId('');
        if (onAssignLayout) {
          onAssignLayout(selectedLayout.id, selectedTenantId);
        }
      }
    } catch (error) {
      console.error('Error assigning layout:', error);
    }
  };

  const filteredLayouts = layouts.filter(layout => {
    const matchesCategory = selectedCategory === 'all' || layout.category === selectedCategory;
    const matchesSearch = layout.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (layout.description?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false);
    return matchesCategory && matchesSearch;
  });

  const categories = ['all', ...new Set(layouts.map(l => l.category))];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <LayoutGrid className="h-6 w-6" />
            Layout Templates
          </h2>
          <p className="text-muted-foreground">
            30 unique layouts for your clients&apos; websites
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Input
            placeholder="Search layouts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-64"
          />
        </div>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <Button
            key={category}
            variant={selectedCategory === category ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedCategory(category)}
            className="capitalize"
          >
            {category === 'all' ? 'All Layouts' : category}
            {category !== 'all' && (
              <Badge variant="secondary" className="ml-2 text-xs">
                {layouts.filter(l => l.category === category).length}
              </Badge>
            )}
          </Button>
        ))}
      </div>

      {/* Layouts Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredLayouts.map((layout) => {
          const CategoryIcon = categoryIcons[layout.category] || LayoutGrid;
          const gradient = getLayoutGradient(layout.category, layout.slug);
          
          return (
            <Card 
              key={layout.id} 
              className={`group relative overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1 cursor-pointer ${
                selectedLayout?.id === layout.id ? 'ring-2 ring-primary' : ''
              }`}
              onClick={() => setSelectedLayout(layout)}
            >
              {/* Preview Image Placeholder */}
              <div className={`h-48 bg-gradient-to-br ${gradient} relative overflow-hidden`}>
                {/* Overlay pattern */}
                <div className="absolute inset-0 opacity-30">
                  <div className="absolute top-4 left-4 w-20 h-3 bg-white/50 rounded"></div>
                  <div className="absolute top-10 left-4 w-16 h-2 bg-white/40 rounded"></div>
                  <div className="absolute bottom-8 left-4 right-4 h-20 bg-white/30 rounded"></div>
                  <div className="absolute bottom-4 left-4 flex gap-2">
                    <div className="w-8 h-8 bg-white/40 rounded"></div>
                    <div className="w-8 h-8 bg-white/40 rounded"></div>
                    <div className="w-8 h-8 bg-white/40 rounded"></div>
                  </div>
                </div>
                
                {/* Premium Badge */}
                {layout.isPremium && (
                  <div className="absolute top-3 right-3">
                    <Badge className="bg-gradient-to-r from-amber-500 to-yellow-500 text-white border-0">
                      <Crown className="h-3 w-3 mr-1" />
                      Premium
                    </Badge>
                  </div>
                )}
                
                {/* Hover overlay */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <Button size="sm" variant="secondary" className="gap-1">
                    <Eye className="h-4 w-4" />
                    Preview
                  </Button>
                </div>
              </div>
              
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg leading-tight">{layout.name}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                      {layout.description}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between mt-3 pt-3 border-t">
                  <div className="flex items-center gap-2">
                    <Badge 
                      variant="outline" 
                      className={`capitalize text-xs ${categoryColors[layout.category]} text-white border-0`}
                    >
                      <CategoryIcon className="h-3 w-3 mr-1" />
                      {layout.category}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Users className="h-3 w-3" />
                    {layout._count?.tenants || 0} sites
                  </div>
                </div>
              </CardContent>
              
              {/* Selected indicator */}
              {selectedLayout?.id === layout.id && (
                <div className="absolute top-2 left-2">
                  <div className="h-6 w-6 rounded-full bg-primary flex items-center justify-center">
                    <Check className="h-4 w-4 text-white" />
                  </div>
                </div>
              )}
            </Card>
          );
        })}
      </div>

      {/* Selected Layout Actions */}
      {selectedLayout && (
        <Card className="fixed bottom-6 left-1/2 -translate-x-1/2 w-full max-w-md shadow-2xl border-primary z-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Wand2 className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium">{selectedLayout.name}</p>
                  <p className="text-xs text-muted-foreground">Selected layout</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setSelectedLayout(null)}
                >
                  Cancel
                </Button>
                <Dialog open={showAssignDialog} onOpenChange={setShowAssignDialog}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      Assign to Tenant
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Assign Layout</DialogTitle>
                      <DialogDescription>
                        Assign &quot;{selectedLayout.name}&quot; to a tenant. This will change their site&apos;s appearance.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="py-4">
                      <Label>Select Tenant</Label>
                      <Select value={selectedTenantId} onValueChange={setSelectedTenantId}>
                        <SelectTrigger className="mt-2">
                          <SelectValue placeholder="Choose a tenant" />
                        </SelectTrigger>
                        <SelectContent>
                          {tenants.map((tenant) => (
                            <SelectItem key={tenant.id} value={tenant.id}>
                              <div className="flex items-center gap-2">
                                <span>{tenant.companyName}</span>
                                {tenant.layout?.name && (
                                  <Badge variant="secondary" className="text-xs">
                                    Current: {tenant.layout.name}
                                  </Badge>
                                )}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setShowAssignDialog(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleAssignLayout} disabled={!selectedTenantId}>
                        Assign Layout
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {filteredLayouts.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <LayoutGrid className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p>No layouts found matching your criteria</p>
        </div>
      )}
    </div>
  );
}
