import { PrismaClient } from '@prisma/client';

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
  });

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db;

// JSON helper utilities for parsing/stringifying JSON fields
export const jsonHelper = {
  // Parse JSON field safely
  parse: <T>(jsonString: string | null, defaultValue: T): T => {
    if (!jsonString) return defaultValue;
    try {
      return JSON.parse(jsonString) as T;
    } catch {
      return defaultValue;
    }
  },

  // Stringify JSON field
  stringify: <T>(value: T): string => {
    return JSON.stringify(value);
  },

  // Get localized value from JSON object
  getLocalized: (
    jsonString: string | null,
    locale: string,
    defaultValue: string = ''
  ): string => {
    const parsed = jsonHelper.parse<Record<string, string>>(jsonString, {});
    return parsed[locale] || parsed['en'] || defaultValue;
  },

  // Set localized value in JSON object
  setLocalized: (
    jsonString: string | null,
    locale: string,
    value: string
  ): string => {
    const parsed = jsonHelper.parse<Record<string, string>>(jsonString, {});
    parsed[locale] = value;
    return JSON.stringify(parsed);
  },
};

// Types for theme configuration
export interface ThemeConfig {
  colors?: {
    primary?: string;
    secondary?: string;
    accent?: string;
    background?: string;
    text?: string;
  };
  typography?: {
    headingFont?: string;
    bodyFont?: string;
  };
  layout?: {
    headerStyle?: 'centered' | 'split' | 'minimal';
    productGrid?: 2 | 3 | 4;
    heroStyle?: 'slider' | 'static' | 'video';
  };
  branding?: {
    logo?: string;
    favicon?: string;
    companyName?: string;
    tagline?: string;
  };
}

// Types for social links
export interface SocialLinks {
  facebook?: string;
  instagram?: string;
  twitter?: string;
  youtube?: string;
  whatsapp?: string;
  tiktok?: string;
}

// Types for SEO settings
export interface SeoSettings {
  metaTitle?: string;
  metaDescription?: string;
  keywords?: string[];
}

// Types for product dimensions
export interface ProductDimensions {
  width?: number;
  height?: number;
  depth?: number;
  unit?: 'cm' | 'in' | 'm';
}

// Types for multi-language content
export interface LocalizedContent {
  en?: string;
  ar?: string;
  he?: string;
}

// Default theme configurations
export const defaultThemePresets: Record<string, ThemeConfig> = {
  modern: {
    colors: {
      primary: '#2563eb',
      secondary: '#1e40af',
      accent: '#10b981',
      background: '#ffffff',
      text: '#1f2937',
    },
    typography: {
      headingFont: 'Inter',
      bodyFont: 'Inter',
    },
    layout: {
      headerStyle: 'centered',
      productGrid: 3,
      heroStyle: 'slider',
    },
  },
  classic: {
    colors: {
      primary: '#92400e',
      secondary: '#78350f',
      accent: '#b45309',
      background: '#fffbeb',
      text: '#1c1917',
    },
    typography: {
      headingFont: 'Playfair Display',
      bodyFont: 'Lora',
    },
    layout: {
      headerStyle: 'split',
      productGrid: 3,
      heroStyle: 'static',
    },
  },
  minimal: {
    colors: {
      primary: '#18181b',
      secondary: '#27272a',
      accent: '#71717a',
      background: '#ffffff',
      text: '#09090b',
    },
    typography: {
      headingFont: 'Inter',
      bodyFont: 'Inter',
    },
    layout: {
      headerStyle: 'minimal',
      productGrid: 4,
      heroStyle: 'static',
    },
  },
  elegant: {
    colors: {
      primary: '#be185d',
      secondary: '#9d174d',
      accent: '#f472b6',
      background: '#fdf4ff',
      text: '#831843',
    },
    typography: {
      headingFont: 'Cormorant Garamond',
      bodyFont: 'Montserrat',
    },
    layout: {
      headerStyle: 'centered',
      productGrid: 3,
      heroStyle: 'slider',
    },
  },
  dark: {
    colors: {
      primary: '#3b82f6',
      secondary: '#2563eb',
      accent: '#60a5fa',
      background: '#0f172a',
      text: '#f1f5f9',
    },
    typography: {
      headingFont: 'Inter',
      bodyFont: 'Inter',
    },
    layout: {
      headerStyle: 'minimal',
      productGrid: 3,
      heroStyle: 'slider',
    },
  },
};
