// 30 Unique Layout Templates for Furniture E-commerce Platform
// Each layout has a distinct visual style and configuration

export const layouts = [
  // ==================== MODERN CATEGORY (6 layouts) ====================
  {
    name: "Modern Minimal",
    slug: "modern-minimal",
    description: "Clean, spacious design with emphasis on white space and simplicity",
    category: "modern",
    isPremium: false,
    order: 1,
    config: JSON.stringify({
      header: { style: "fixed", transparent: true, logoPosition: "center", height: 80 },
      hero: { type: "fullWidth", animation: "fade", overlay: false, height: "100vh" },
      productGrid: { columns: 3, gap: 32, cardStyle: "minimal", showQuickView: true },
      footer: { style: "minimal", showNewsletter: false, columns: 2 },
      sidebar: { enabled: false },
      typography: { headingFont: "Inter", bodyFont: "Inter", headingWeight: 300 },
      animations: { enabled: true, type: "subtle", duration: 300 },
      colors: { preset: "light", primary: "#000000", background: "#FFFFFF" },
      features: { megaMenu: false, stickyProductInfo: true, infiniteScroll: true }
    })
  },
  {
    name: "Modern Edge",
    slug: "modern-edge",
    description: "Sharp angles and bold typography with asymmetric layouts",
    category: "modern",
    isPremium: false,
    order: 2,
    config: JSON.stringify({
      header: { style: "sticky", transparent: false, logoPosition: "left", height: 70, border: true },
      hero: { type: "split", animation: "slide", overlay: true, height: "80vh" },
      productGrid: { columns: 4, gap: 16, cardStyle: "bordered", showQuickView: false },
      footer: { style: "expanded", showNewsletter: true, columns: 4 },
      sidebar: { enabled: true, position: "left", width: 280 },
      typography: { headingFont: "Space Grotesk", bodyFont: "DM Sans", headingWeight: 700 },
      animations: { enabled: true, type: "sharp", duration: 200 },
      colors: { preset: "monochrome", primary: "#1a1a1a", accent: "#FF3366" },
      features: { megaMenu: true, stickyProductInfo: false, infiniteScroll: false }
    })
  },
  {
    name: "Nordic Breeze",
    slug: "nordic-breeze",
    description: "Scandinavian-inspired design with natural tones and organic shapes",
    category: "modern",
    isPremium: false,
    order: 3,
    config: JSON.stringify({
      header: { style: "fixed", transparent: true, logoPosition: "left", height: 90 },
      hero: { type: "carousel", animation: "soft", overlay: false, height: "70vh" },
      productGrid: { columns: 3, gap: 40, cardStyle: "elevated", showQuickView: true },
      footer: { style: "simple", showNewsletter: true, columns: 3 },
      sidebar: { enabled: false },
      typography: { headingFont: "Cormorant Garamond", bodyFont: "Lato", headingWeight: 400 },
      animations: { enabled: true, type: "smooth", duration: 500 },
      colors: { preset: "warm", primary: "#8B7355", background: "#F5F1EB" },
      features: { megaMenu: false, stickyProductInfo: true, infiniteScroll: true }
    })
  },
  {
    name: "Tech Forward",
    slug: "tech-forward",
    description: "Futuristic design with gradients, glass effects, and smooth animations",
    category: "modern",
    isPremium: true,
    order: 4,
    config: JSON.stringify({
      header: { style: "glass", transparent: true, logoPosition: "center", height: 75, blur: true },
      hero: { type: "video", animation: "morph", overlay: true, height: "100vh" },
      productGrid: { columns: 3, gap: 24, cardStyle: "glass", showQuickView: true },
      footer: { style: "modern", showNewsletter: true, columns: 3 },
      sidebar: { enabled: false },
      typography: { headingFont: "Outfit", bodyFont: "Outfit", headingWeight: 500 },
      animations: { enabled: true, type: "morphing", duration: 600 },
      colors: { preset: "gradient", primary: "#6366F1", background: "#0F0F23" },
      features: { megaMenu: true, stickyProductInfo: true, infiniteScroll: true, darkMode: true }
    })
  },
  {
    name: "Urban Loft",
    slug: "urban-loft",
    description: "Industrial-chic aesthetic with exposed textures and raw elements",
    category: "modern",
    isPremium: false,
    order: 5,
    config: JSON.stringify({
      header: { style: "static", transparent: false, logoPosition: "left", height: 85, dark: true },
      hero: { type: "static", animation: "none", overlay: true, height: "60vh" },
      productGrid: { columns: 3, gap: 20, cardStyle: "industrial", showQuickView: true },
      footer: { style: "dark", showNewsletter: false, columns: 4 },
      sidebar: { enabled: true, position: "right", width: 300 },
      typography: { headingFont: "Bebas Neue", bodyFont: "Roboto", headingWeight: 400 },
      animations: { enabled: false, type: "none", duration: 0 },
      colors: { preset: "industrial", primary: "#D4A574", background: "#2C2C2C" },
      features: { megaMenu: false, stickyProductInfo: false, infiniteScroll: false }
    })
  },
  {
    name: "Fresh Bloom",
    slug: "fresh-bloom",
    description: "Light, airy design with soft colors and playful elements",
    category: "modern",
    isPremium: false,
    order: 6,
    config: JSON.stringify({
      header: { style: "floating", transparent: true, logoPosition: "center", height: 70, rounded: true },
      hero: { type: "parallax", animation: "float", overlay: false, height: "85vh" },
      productGrid: { columns: 4, gap: 28, cardStyle: "rounded", showQuickView: true },
      footer: { style: "playful", showNewsletter: true, columns: 3 },
      sidebar: { enabled: false },
      typography: { headingFont: "Quicksand", bodyFont: "Quicksand", headingWeight: 600 },
      animations: { enabled: true, type: "bouncy", duration: 400 },
      colors: { preset: "pastel", primary: "#F472B6", background: "#FEFEFE" },
      features: { megaMenu: false, stickyProductInfo: true, infiniteScroll: true }
    })
  },

  // ==================== LUXURY CATEGORY (6 layouts) ====================
  {
    name: "Royal Elegance",
    slug: "royal-elegance",
    description: "Opulent design with gold accents and sophisticated typography",
    category: "luxury",
    isPremium: true,
    order: 7,
    config: JSON.stringify({
      header: { style: "elegant", transparent: false, logoPosition: "center", height: 100, gold: true },
      hero: { type: "fullScreen", animation: "elegant", overlay: true, height: "100vh" },
      productGrid: { columns: 3, gap: 48, cardStyle: "luxury", showQuickView: true },
      footer: { style: "ornate", showNewsletter: true, columns: 4 },
      sidebar: { enabled: false },
      typography: { headingFont: "Playfair Display", bodyFont: "Lora", headingWeight: 500 },
      animations: { enabled: true, type: "elegant", duration: 800 },
      colors: { preset: "luxury", primary: "#D4AF37", background: "#0A0A0A" },
      features: { megaMenu: true, stickyProductInfo: true, infiniteScroll: false, darkMode: true }
    })
  },
  {
    name: "Velvet Night",
    slug: "velvet-night",
    description: "Dark, moody aesthetic with rich textures and dramatic lighting",
    category: "luxury",
    isPremium: true,
    order: 8,
    config: JSON.stringify({
      header: { style: "minimal-dark", transparent: true, logoPosition: "left", height: 80 },
      hero: { type: "cinematic", animation: "reveal", overlay: true, height: "100vh" },
      productGrid: { columns: 3, gap: 36, cardStyle: "dark-luxury", showQuickView: true },
      footer: { style: "dark-minimal", showNewsletter: true, columns: 3 },
      sidebar: { enabled: false },
      typography: { headingFont: "Cinzel", bodyFont: "Cormorant", headingWeight: 400 },
      animations: { enabled: true, type: "cinematic", duration: 1000 },
      colors: { preset: "velvet", primary: "#4A0E4E", background: "#0D0D0D" },
      features: { megaMenu: false, stickyProductInfo: true, infiniteScroll: false, darkMode: true }
    })
  },
  {
    name: "Marble & Gold",
    slug: "marble-gold",
    description: "Classic luxury with marble textures and gold embellishments",
    category: "luxury",
    isPremium: true,
    order: 9,
    config: JSON.stringify({
      header: { style: "classic", transparent: false, logoPosition: "center", height: 95 },
      hero: { type: "slider", animation: "classic", overlay: true, height: "80vh" },
      productGrid: { columns: 4, gap: 32, cardStyle: "marble", showQuickView: true },
      footer: { style: "classic", showNewsletter: true, columns: 4 },
      sidebar: { enabled: true, position: "left", width: 320 },
      typography: { headingFont: "Bodoni Moda", bodyFont: "Libre Baskerville", headingWeight: 500 },
      animations: { enabled: true, type: "classic", duration: 600 },
      colors: { preset: "marble", primary: "#B8860B", background: "#F5F5F5" },
      features: { megaMenu: true, stickyProductInfo: false, infiniteScroll: false }
    })
  },
  {
    name: "Timeless Classic",
    slug: "timeless-classic",
    description: "Enduring elegance with traditional layouts and refined details",
    category: "luxury",
    isPremium: true,
    order: 10,
    config: JSON.stringify({
      header: { style: "traditional", transparent: false, logoPosition: "center", height: 110 },
      hero: { type: "classic-slider", animation: "fade", overlay: false, height: "70vh" },
      productGrid: { columns: 3, gap: 40, cardStyle: "classic", showQuickView: false },
      footer: { style: "traditional", showNewsletter: true, columns: 4 },
      sidebar: { enabled: false },
      typography: { headingFont: "Garamond", bodyFont: "Georgia", headingWeight: 400 },
      animations: { enabled: true, type: "subtle", duration: 500 },
      colors: { preset: "classic", primary: "#2F4F4F", background: "#FAFAFA" },
      features: { megaMenu: false, stickyProductInfo: false, infiniteScroll: false }
    })
  },
  {
    name: "Platinum Suite",
    slug: "platinum-suite",
    description: "High-end minimal luxury with platinum accents",
    category: "luxury",
    isPremium: true,
    order: 11,
    config: JSON.stringify({
      header: { style: "ultra-minimal", transparent: true, logoPosition: "left", height: 75 },
      hero: { type: "minimal", animation: "slow", overlay: false, height: "90vh" },
      productGrid: { columns: 3, gap: 60, cardStyle: "platinum", showQuickView: true },
      footer: { style: "ultra-minimal", showNewsletter: false, columns: 2 },
      sidebar: { enabled: false },
      typography: { headingFont: "Montserrat", bodyFont: "Montserrat", headingWeight: 300 },
      animations: { enabled: true, type: "smooth", duration: 700 },
      colors: { preset: "platinum", primary: "#E5E4E2", background: "#FFFFFF" },
      features: { megaMenu: false, stickyProductInfo: true, infiniteScroll: true }
    })
  },
  {
    name: "Diamond Collection",
    slug: "diamond-collection",
    description: "Sparkling design with geometric patterns and premium feel",
    category: "luxury",
    isPremium: true,
    order: 12,
    config: JSON.stringify({
      header: { style: "geometric", transparent: true, logoPosition: "center", height: 85 },
      hero: { type: "geometric", animation: "geometric", overlay: true, height: "100vh" },
      productGrid: { columns: 3, gap: 28, cardStyle: "diamond", showQuickView: true },
      footer: { style: "geometric", showNewsletter: true, columns: 3 },
      sidebar: { enabled: false },
      typography: { headingFont: "Poiret One", bodyFont: "Raleway", headingWeight: 400 },
      animations: { enabled: true, type: "geometric", duration: 500 },
      colors: { preset: "diamond", primary: "#B9F2FF", background: "#1A1A2E" },
      features: { megaMenu: true, stickyProductInfo: true, infiniteScroll: true, darkMode: true }
    })
  },

  // ==================== MINIMAL CATEGORY (6 layouts) ====================
  {
    name: "Pure White",
    slug: "pure-white",
    description: "Ultra-minimal all-white design for maximum product focus",
    category: "minimal",
    isPremium: false,
    order: 13,
    config: JSON.stringify({
      header: { style: "hidden", transparent: true, logoPosition: "left", height: 60, showOnScroll: true },
      hero: { type: "minimal", animation: "none", overlay: false, height: "50vh" },
      productGrid: { columns: 4, gap: 20, cardStyle: "invisible", showQuickView: false },
      footer: { style: "invisible", showNewsletter: false, columns: 1 },
      sidebar: { enabled: false },
      typography: { headingFont: "Helvetica Neue", bodyFont: "Helvetica Neue", headingWeight: 300 },
      animations: { enabled: false, type: "none", duration: 0 },
      colors: { preset: "pure-white", primary: "#000000", background: "#FFFFFF" },
      features: { megaMenu: false, stickyProductInfo: false, infiniteScroll: true }
    })
  },
  {
    name: "Zen Garden",
    slug: "zen-garden",
    description: "Japanese-inspired minimalism with perfect balance and harmony",
    category: "minimal",
    isPremium: false,
    order: 14,
    config: JSON.stringify({
      header: { style: "zen", transparent: true, logoPosition: "center", height: 70 },
      hero: { type: "zen", animation: "calm", overlay: false, height: "70vh" },
      productGrid: { columns: 2, gap: 80, cardStyle: "zen", showQuickView: true },
      footer: { style: "zen", showNewsletter: false, columns: 1 },
      sidebar: { enabled: false },
      typography: { headingFont: "Noto Serif JP", bodyFont: "Noto Sans JP", headingWeight: 400 },
      animations: { enabled: true, type: "zen", duration: 800 },
      colors: { preset: "zen", primary: "#5D5D5D", background: "#F7F7F5" },
      features: { megaMenu: false, stickyProductInfo: false, infiniteScroll: false }
    })
  },
  {
    name: "Swiss Style",
    slug: "swiss-style",
    description: "Grid-based design inspired by Swiss typography and graphic design",
    category: "minimal",
    isPremium: false,
    order: 15,
    config: JSON.stringify({
      header: { style: "grid", transparent: false, logoPosition: "left", height: 80 },
      hero: { type: "grid", animation: "instant", overlay: false, height: "60vh" },
      productGrid: { columns: 4, gap: 16, cardStyle: "grid", showQuickView: false },
      footer: { style: "grid", showNewsletter: false, columns: 2 },
      sidebar: { enabled: false },
      typography: { headingFont: "Helvetica Neue", bodyFont: "Helvetica Neue", headingWeight: 700 },
      animations: { enabled: false, type: "none", duration: 0 },
      colors: { preset: "swiss", primary: "#FF0000", background: "#FFFFFF" },
      features: { megaMenu: false, stickyProductInfo: false, infiniteScroll: false }
    })
  },
  {
    name: "Mono Chrome",
    slug: "mono-chrome",
    description: "Bold black and white design with high contrast",
    category: "minimal",
    isPremium: false,
    order: 16,
    config: JSON.stringify({
      header: { style: "contrast", transparent: false, logoPosition: "center", height: 75, dark: true },
      hero: { type: "contrast", animation: "sharp", overlay: true, height: "80vh" },
      productGrid: { columns: 3, gap: 24, cardStyle: "contrast", showQuickView: true },
      footer: { style: "contrast", showNewsletter: true, columns: 3 },
      sidebar: { enabled: false },
      typography: { headingFont: "Druk Wide", bodyFont: "IBM Plex Sans", headingWeight: 700 },
      animations: { enabled: true, type: "sharp", duration: 200 },
      colors: { preset: "mono", primary: "#FFFFFF", background: "#000000" },
      features: { megaMenu: true, stickyProductInfo: false, infiniteScroll: true, darkMode: true }
    })
  },
  {
    name: "Breathing Space",
    slug: "breathing-space",
    description: "Extra-wide margins and generous padding for visual rest",
    category: "minimal",
    isPremium: false,
    order: 17,
    config: JSON.stringify({
      header: { style: "spaced", transparent: true, logoPosition: "left", height: 100 },
      hero: { type: "spaced", animation: "slow", overlay: false, height: "60vh" },
      productGrid: { columns: 2, gap: 100, cardStyle: "spaced", showQuickView: false },
      footer: { style: "spaced", showNewsletter: false, columns: 1 },
      sidebar: { enabled: false },
      typography: { headingFont: "Light", bodyFont: "Light", headingWeight: 300 },
      animations: { enabled: true, type: "slow", duration: 1000 },
      colors: { preset: "light", primary: "#333333", background: "#FAFAFA" },
      features: { megaMenu: false, stickyProductInfo: false, infiniteScroll: false }
    })
  },
  {
    name: "Outline",
    slug: "outline",
    description: "Thin borders and outlined elements for structured minimalism",
    category: "minimal",
    isPremium: false,
    order: 18,
    config: JSON.stringify({
      header: { style: "outlined", transparent: false, logoPosition: "left", height: 70, border: true },
      hero: { type: "outlined", animation: "draw", overlay: false, height: "65vh" },
      productGrid: { columns: 3, gap: 32, cardStyle: "outlined", showQuickView: false },
      footer: { style: "outlined", showNewsletter: false, columns: 3 },
      sidebar: { enabled: true, position: "left", width: 250 },
      typography: { headingFont: "Work Sans", bodyFont: "Work Sans", headingWeight: 400 },
      animations: { enabled: true, type: "draw", duration: 400 },
      colors: { preset: "outline", primary: "#000000", background: "#FFFFFF" },
      features: { megaMenu: false, stickyProductInfo: false, infiniteScroll: true }
    })
  },

  // ==================== CREATIVE CATEGORY (6 layouts) ====================
  {
    name: "Bold Statements",
    slug: "bold-statements",
    description: "Daring typography and large-scale visual elements",
    category: "creative",
    isPremium: true,
    order: 19,
    config: JSON.stringify({
      header: { style: "bold", transparent: true, logoPosition: "center", height: 90 },
      hero: { type: "typography", animation: "bold", overlay: true, height: "100vh" },
      productGrid: { columns: 2, gap: 60, cardStyle: "bold", showQuickView: true },
      footer: { style: "bold", showNewsletter: true, columns: 2 },
      sidebar: { enabled: false },
      typography: { headingFont: "Anton", bodyFont: "Barlow", headingWeight: 400 },
      animations: { enabled: true, type: "bold", duration: 300 },
      colors: { preset: "vibrant", primary: "#FF4500", background: "#1A1A1A" },
      features: { megaMenu: true, stickyProductInfo: true, infiniteScroll: false, darkMode: true }
    })
  },
  {
    name: "Art Gallery",
    slug: "art-gallery",
    description: "Museum-inspired layout with focus on visual presentation",
    category: "creative",
    isPremium: true,
    order: 20,
    config: JSON.stringify({
      header: { style: "gallery", transparent: true, logoPosition: "left", height: 60 },
      hero: { type: "gallery", animation: "none", overlay: false, height: "90vh" },
      productGrid: { columns: 3, gap: 60, cardStyle: "gallery", showQuickView: true },
      footer: { style: "gallery", showNewsletter: false, columns: 1 },
      sidebar: { enabled: false },
      typography: { headingFont: "Libre Baskerville", bodyFont: "Libre Franklin", headingWeight: 400 },
      animations: { enabled: false, type: "none", duration: 0 },
      colors: { preset: "gallery", primary: "#333333", background: "#FFFFFF" },
      features: { megaMenu: false, stickyProductInfo: false, infiniteScroll: false }
    })
  },
  {
    name: "Magazine Editorial",
    slug: "magazine-editorial",
    description: "Fashion magazine-inspired layout with dynamic compositions",
    category: "creative",
    isPremium: true,
    order: 21,
    config: JSON.stringify({
      header: { style: "editorial", transparent: false, logoPosition: "center", height: 100 },
      hero: { type: "editorial", animation: "dynamic", overlay: true, height: "85vh" },
      productGrid: { columns: 3, gap: 24, cardStyle: "editorial", showQuickView: true },
      footer: { style: "editorial", showNewsletter: true, columns: 4 },
      sidebar: { enabled: false },
      typography: { headingFont: "Vogue", bodyFont: "Lora", headingWeight: 500 },
      animations: { enabled: true, type: "editorial", duration: 600 },
      colors: { preset: "editorial", primary: "#8B0000", background: "#FFFFFF" },
      features: { megaMenu: false, stickyProductInfo: true, infiniteScroll: true }
    })
  },
  {
    name: "Retro Wave",
    slug: "retro-wave",
    description: "80s-inspired neon colors and synthwave aesthetics",
    category: "creative",
    isPremium: true,
    order: 22,
    config: JSON.stringify({
      header: { style: "neon", transparent: true, logoPosition: "center", height: 80 },
      hero: { type: "neon", animation: "pulse", overlay: true, height: "100vh" },
      productGrid: { columns: 3, gap: 28, cardStyle: "neon", showQuickView: true },
      footer: { style: "neon", showNewsletter: true, columns: 3 },
      sidebar: { enabled: false },
      typography: { headingFont: "Orbitron", bodyFont: "Rajdhani", headingWeight: 700 },
      animations: { enabled: true, type: "neon", duration: 400 },
      colors: { preset: "synthwave", primary: "#FF00FF", background: "#0D0221" },
      features: { megaMenu: true, stickyProductInfo: true, infiniteScroll: true, darkMode: true }
    })
  },
  {
    name: "Brutalist",
    slug: "brutalist",
    description: "Raw, unpolished aesthetic with bold structural elements",
    category: "creative",
    isPremium: false,
    order: 23,
    config: JSON.stringify({
      header: { style: "brutalist", transparent: false, logoPosition: "left", height: 70 },
      hero: { type: "brutalist", animation: "none", overlay: false, height: "70vh" },
      productGrid: { columns: 4, gap: 4, cardStyle: "brutalist", showQuickView: false },
      footer: { style: "brutalist", showNewsletter: false, columns: 2 },
      sidebar: { enabled: true, position: "left", width: 280 },
      typography: { headingFont: "Courier New", bodyFont: "Courier New", headingWeight: 700 },
      animations: { enabled: false, type: "none", duration: 0 },
      colors: { preset: "brutalist", primary: "#FF0000", background: "#FFFFFF" },
      features: { megaMenu: false, stickyProductInfo: false, infiniteScroll: false }
    })
  },
  {
    name: "Collage",
    slug: "collage",
    description: "Mixed-media inspired layout with overlapping elements",
    category: "creative",
    isPremium: true,
    order: 24,
    config: JSON.stringify({
      header: { style: "floating", transparent: true, logoPosition: "center", height: 75 },
      hero: { type: "collage", animation: "random", overlay: true, height: "90vh" },
      productGrid: { columns: 3, gap: 20, cardStyle: "collage", showQuickView: true },
      footer: { style: "collage", showNewsletter: true, columns: 3 },
      sidebar: { enabled: false },
      typography: { headingFont: "Permanent Marker", bodyFont: "Roboto", headingWeight: 400 },
      animations: { enabled: true, type: "random", duration: 500 },
      colors: { preset: "collage", primary: "#FF6B6B", background: "#F8F8F8" },
      features: { megaMenu: false, stickyProductInfo: false, infiniteScroll: true }
    })
  },

  // ==================== CLASSIC CATEGORY (6 layouts) ====================
  {
    name: "Heritage Oak",
    slug: "heritage-oak",
    description: "Traditional woodworking-inspired with warm wood tones",
    category: "classic",
    isPremium: false,
    order: 25,
    config: JSON.stringify({
      header: { style: "wood", transparent: false, logoPosition: "center", height: 95 },
      hero: { type: "classic", animation: "fade", overlay: true, height: "65vh" },
      productGrid: { columns: 3, gap: 36, cardStyle: "wood", showQuickView: false },
      footer: { style: "wood", showNewsletter: true, columns: 4 },
      sidebar: { enabled: false },
      typography: { headingFont: "Merriweather", bodyFont: "Open Sans", headingWeight: 700 },
      animations: { enabled: true, type: "classic", duration: 400 },
      colors: { preset: "wood", primary: "#8B4513", background: "#FDF5E6" },
      features: { megaMenu: false, stickyProductInfo: false, infiniteScroll: false }
    })
  },
  {
    name: "Victorian Grace",
    slug: "victorian-grace",
    description: "19th century-inspired ornate design with elegant details",
    category: "classic",
    isPremium: true,
    order: 26,
    config: JSON.stringify({
      header: { style: "victorian", transparent: false, logoPosition: "center", height: 110 },
      hero: { type: "ornate", animation: "elegant", overlay: true, height: "75vh" },
      productGrid: { columns: 3, gap: 44, cardStyle: "ornate", showQuickView: true },
      footer: { style: "ornate", showNewsletter: true, columns: 4 },
      sidebar: { enabled: false },
      typography: { headingFont: "Pinyon Script", bodyFont: "Cormorant Garamond", headingWeight: 400 },
      animations: { enabled: true, type: "elegant", duration: 700 },
      colors: { preset: "victorian", primary: "#800020", background: "#FFFFF0" },
      features: { megaMenu: false, stickyProductInfo: false, infiniteScroll: false }
    })
  },
  {
    name: "Coastal Breeze",
    slug: "coastal-breeze",
    description: "Beach-inspired relaxed design with ocean tones",
    category: "classic",
    isPremium: false,
    order: 27,
    config: JSON.stringify({
      header: { style: "coastal", transparent: true, logoPosition: "left", height: 80 },
      hero: { type: "coastal", animation: "wave", overlay: false, height: "70vh" },
      productGrid: { columns: 3, gap: 32, cardStyle: "coastal", showQuickView: true },
      footer: { style: "coastal", showNewsletter: true, columns: 3 },
      sidebar: { enabled: false },
      typography: { headingFont: "Nunito", bodyFont: "Nunito", headingWeight: 600 },
      animations: { enabled: true, type: "wave", duration: 500 },
      colors: { preset: "coastal", primary: "#20B2AA", background: "#F5FFFA" },
      features: { megaMenu: false, stickyProductInfo: true, infiniteScroll: true }
    })
  },
  {
    name: "Farmhouse Charm",
    slug: "farmhouse-charm",
    description: "Rustic country-inspired with cozy, homey feel",
    category: "classic",
    isPremium: false,
    order: 28,
    config: JSON.stringify({
      header: { style: "farmhouse", transparent: false, logoPosition: "left", height: 85 },
      hero: { type: "farmhouse", animation: "cozy", overlay: false, height: "60vh" },
      productGrid: { columns: 3, gap: 28, cardStyle: "farmhouse", showQuickView: false },
      footer: { style: "farmhouse", showNewsletter: true, columns: 3 },
      sidebar: { enabled: true, position: "left", width: 260 },
      typography: { headingFont: "Playfair Display", bodyFont: "Lora", headingWeight: 500 },
      animations: { enabled: true, type: "cozy", duration: 400 },
      colors: { preset: "farmhouse", primary: "#8B7355", background: "#FFFAF0" },
      features: { megaMenu: false, stickyProductInfo: false, infiniteScroll: false }
    })
  },
  {
    name: "Mediterranean Villa",
    slug: "mediterranean-villa",
    description: "Southern European-inspired with terracotta and olive tones",
    category: "classic",
    isPremium: true,
    order: 29,
    config: JSON.stringify({
      header: { style: "mediterranean", transparent: false, logoPosition: "center", height: 90 },
      hero: { type: "mediterranean", animation: "warm", overlay: true, height: "75vh" },
      productGrid: { columns: 3, gap: 40, cardStyle: "mediterranean", showQuickView: true },
      footer: { style: "mediterranean", showNewsletter: true, columns: 4 },
      sidebar: { enabled: false },
      typography: { headingFont: "Cormorant Garamond", bodyFont: "Source Sans Pro", headingWeight: 400 },
      animations: { enabled: true, type: "warm", duration: 500 },
      colors: { preset: "mediterranean", primary: "#CD853F", background: "#FFF8DC" },
      features: { megaMenu: false, stickyProductInfo: false, infiniteScroll: false }
    })
  },
  {
    name: "English Garden",
    slug: "english-garden",
    description: "Botanical-inspired with floral patterns and soft greens",
    category: "classic",
    isPremium: true,
    order: 30,
    config: JSON.stringify({
      header: { style: "botanical", transparent: true, logoPosition: "center", height: 85 },
      hero: { type: "botanical", animation: "bloom", overlay: false, height: "65vh" },
      productGrid: { columns: 3, gap: 36, cardStyle: "botanical", showQuickView: true },
      footer: { style: "botanical", showNewsletter: true, columns: 3 },
      sidebar: { enabled: false },
      typography: { headingFont: "Cormorant", bodyFont: "Karla", headingWeight: 400 },
      animations: { enabled: true, type: "bloom", duration: 600 },
      colors: { preset: "garden", primary: "#228B22", background: "#F0FFF0" },
      features: { megaMenu: false, stickyProductInfo: true, infiniteScroll: true }
    })
  }
];

// Function to seed layouts
export async function seedLayouts(prisma: any) {
  console.log('Seeding layouts...');
  
  for (const layout of layouts) {
    await prisma.layout.upsert({
      where: { slug: layout.slug },
      update: layout,
      create: layout,
    });
  }
  
  console.log(`Seeded ${layouts.length} layouts`);
}
